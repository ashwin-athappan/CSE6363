# RUN THE FOLLOWING COMMANDS IN YOUR TERMINAL
Use python 3.10
```bashsupport pro shell script
pip install --upgrade pip
pip install numpy==1.23.5
pip install gym
pip install torch 
pip install torchvision
pip install seaborn 
pip install "gym[atari,accept-rom-license]"
pip install autorom
AutoROM --accept-license
```

### Find the notebooks in the notebook directory


### If you want to see the program open up the game rom and play then run the python files in the python directory
